const questions = [
  { question: "What is the capital of Germany?", answers: ["Berlin", "Munich", "Frankfurt"], correct: 0 },
  { question: "Which planet is known as the Red Planet?", answers: ["Earth", "Mars", "Venus"], correct: 1 },
  { question: "Which gas do plants use for photosynthesis?", answers: ["Oxygen", "Nitrogen", "Carbon Dioxide"], correct: 2 },
  { question: "What is 5 + 7?", answers: ["10", "12", "14"], correct: 1 },
  { question: "Which ocean is the largest?", answers: ["Atlantic", "Indian", "Pacific"], correct: 2 }
];

const wheelCanvas = document.getElementById("wheelCanvas");
const ctx = wheelCanvas.getContext("2d");
const numSegments = questions.length;
const anglePerSegment = (2 * Math.PI) / numSegments;
let rotation = 0;
let spinning = false;

function drawWheel() {
  const colors = ["#00BFFF", "#32CD32", "#FFA500", "#FF69B4", "#BA55D3"];
  for (let i = 0; i < numSegments; i++) {
    const angle = i * anglePerSegment;
    ctx.beginPath();
    ctx.moveTo(250, 250);
    ctx.arc(250, 250, 200, angle, angle + anglePerSegment);
    ctx.fillStyle = colors[i % colors.length];
    ctx.fill();
    ctx.stroke();

    ctx.save();
    ctx.translate(250, 250);
    ctx.rotate(angle + anglePerSegment / 2);
    ctx.textAlign = "right";
    ctx.fillStyle = "#fff";
    ctx.font = "bold 18px Poppins";
    ctx.fillText(`Q${i + 1}`, 180, 10);
    ctx.restore();
  }

  ctx.beginPath();
  ctx.moveTo(250, 50);
  ctx.lineTo(240, 30);
  ctx.lineTo(260, 30);
  ctx.closePath();
  ctx.fillStyle = "#333";
  ctx.fill();
}

drawWheel();

document.getElementById("startButton").onclick = () => spinWheel();

function spinWheel() {
  if (spinning) return;
  spinning = true;
  document.getElementById("welcome").classList.add("hidden");
  document.getElementById("wheelSection").classList.remove("hidden");

  let spinTime = 3000 + Math.random() * 1000;
  const start = performance.now();

  function animateWheel(time) {
    const elapsed = time - start;
    const progress = Math.min(elapsed / spinTime, 1);
    const easeOut = 1 - Math.pow(1 - progress, 4);
    rotation = easeOut * (8 * 2 * Math.PI);
    ctx.clearRect(0, 0, 500, 500);
    ctx.save();
    ctx.translate(250, 250);
    ctx.rotate(rotation);
    ctx.translate(-250, -250);
    drawWheel();
    ctx.restore();

    if (progress < 1) {
      requestAnimationFrame(animateWheel);
    } else {
      const landedIndex = (numSegments - Math.floor((rotation % (2 * Math.PI)) / anglePerSegment) - 1 + numSegments) % numSegments;
      setTimeout(() => showQuestion(landedIndex), 500);
    }
  }

  requestAnimationFrame(animateWheel);
}

function showQuestion(index) {
  document.getElementById("wheelSection").classList.add("hidden");
  document.getElementById("questionSection").classList.remove("hidden");

  const q = questions[index];
  document.getElementById("questionText").textContent = q.question;

  const answersDiv = document.getElementById("answers");
  answersDiv.innerHTML = "";
  q.answers.forEach((ans, i) => {
    const btn = document.createElement("button");
    btn.textContent = ans;
    btn.onclick = () => showFeedback(i === q.correct, q.answers[q.correct]);
    answersDiv.appendChild(btn);
  });
}

function showFeedback(correct, correctAnswer) {
  document.getElementById("questionSection").classList.add("hidden");
  document.getElementById("feedbackSection").classList.remove("hidden");
  document.getElementById("resultText").textContent = correct
    ? "Correct!"
    : `Wrong! Correct answer: ${correctAnswer}`;

  setTimeout(() => {
    document.getElementById("feedbackSection").classList.add("hidden");
    document.getElementById("welcome").classList.remove("hidden");
    spinning = false;
  }, 3000);
}
